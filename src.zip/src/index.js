// index.js is a Bridge file 
// connect index.html with App Component (Root Component)
import {App} from './App';
import ReactDOM from 'react-dom';
// It interact with DOM for painting
ReactDOM.render(<App/>, document.getElementById('root'));