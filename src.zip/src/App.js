// App is a Root Component
// object - Data (State)/ Property  + Behaviour (Functions)

import { Resume } from "./pages/Resume";

// App function is wrap in object and then export.
export function App(){
  return (<Resume/>)
}