import React from 'react'

export const Photo = () => {
  return (
    <div>
        <img src="https://s15952.pcdn.co/wp-content/uploads/2022/03/sb-hero-home2-min.png"/>
    </div>
  )
}
