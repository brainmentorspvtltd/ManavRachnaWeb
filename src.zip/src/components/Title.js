import React from 'react'

export const Title = () => {
  return (
   <h1 className='alert-success text-center'>Web Resume </h1>
  )
}
