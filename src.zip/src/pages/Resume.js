import { About } from "../components/About";
import { Photo } from "../components/Photo";
import { Title } from "../components/Title";

export const Resume = ()=><div className="container">
     <Title/>
    <div className="row">
        <div className="col">
        <Photo/>
        </div>
        <div className="col">
            <About/>
        </div>
    </div>
   
    
</div>